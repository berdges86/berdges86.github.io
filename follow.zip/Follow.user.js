// ==UserScript==

// @name         Follow

// @namespace    Violentmonkey

// @version      6.1

// @description  Плавное следование за ровером

// @match        *://*/*

// @grant        none

// ==/UserScript==

(() => {

  'use strict';

  const ROVER_SELECTORS = [

    '.map-rover__icon',

    '.vector-map-rover__icon_icon_arrow',

    '[class*="rover__icon"]',

    '.vector-map-rover__icon.vector-map-rover__icon_icon_arrow.vector-map-rover__icon_animated'

  ];

  const MAP_SELECTORS = [

    '.sdc-vector-map-wrapper',

    '.sdc-map-wrapper',

    '.ymaps3x0--map-container',

    '.leaflet-container'

  ];

  const SMOOTHNESS = 0.25;

  const DEAD_ZONE_RADIUS = 40;

  const MAX_GESTURE_PIXELS = 120;

  const STEP_MS = 40;

  const AUTO_CENTER_DELAY = 220;

  let modeActive = false;

  let roverEl = null;

  let mapEl = null;

  let panningInProgress = false;

  let loopRaf = null;

  let btn = null;

  function findRover() {

    for (const s of ROVER_SELECTORS) {

      const el = document.querySelector(s);

      if (el) return el;

    }

    return null;

  }

  function findMap() {

    for (const s of MAP_SELECTORS) {

      const el = document.querySelector(s);

      if (el) return el;

    }

    return document.querySelector('.map') || document.querySelector('[role="application"]');

  }

  function createButton() {

    const button = document.createElement('button');

    button.textContent = '🎯 Follow: Off';

    Object.assign(button.style, {

      position: 'fixed',

      top: '200px',

      right: '20px',

      zIndex: 1000000,

      background: '#8A2BE2',

      color: '#fff',

      padding: '10px 15px',

      border: 'none',

      borderRadius: '6px',

      fontSize: '14px',

      fontWeight: 'bold',

      cursor: 'pointer',

      opacity: '0.9'

    });

    return button;

  }

  function createPointerEvent(type, clientX, clientY, pointerType = 'touch') {

    try {

      return new PointerEvent(type, {

        bubbles: true,

        cancelable: true,

        clientX,

        clientY,

        pointerType,

        isPrimary: true,

        pointerId: 1

      });

    } catch (e) {

      return new MouseEvent(type.replace('pointer', 'mouse'), {

        bubbles: true,

        cancelable: true,

        clientX,

        clientY,

        buttons: (type === 'pointerdown' || type === 'pointermove') ? 1 : 0

      });

    }

  }

  function dispatchOn(el, ev) {

    try {

      return el.dispatchEvent(ev);

    } catch (e) {

      return false;

    }

  }

  async function syntheticPan(dx, dy) {

    if (!mapEl || panningInProgress) return;



    panningInProgress = true;

    const startX = Math.floor(window.innerWidth / 2 - dx);

    const startY = Math.floor(window.innerHeight / 2 - dy);

    const totalDx = dx;

    const totalDy = dy;

    const stepsCount = Math.max(1, Math.ceil(Math.hypot(totalDx, totalDy) / Math.max(20, MAX_GESTURE_PIXELS / 2)));

    const stepDx = totalDx / stepsCount;

    const stepDy = totalDy / stepsCount;

    try {

      const downEv = createPointerEvent('pointerdown', startX, startY);

      dispatchOn(mapEl, downEv);

      dispatchOn(document.elementFromPoint(startX, startY) || mapEl, downEv);

      for (let i = 1; i <= stepsCount; i++) {

        const px = Math.round(startX + stepDx * i);

        const py = Math.round(startY + stepDy * i);

        const moveEv = createPointerEvent('pointermove', px, py);

        dispatchOn(mapEl, moveEv);

        dispatchOn(document.elementFromPoint(px, py) || mapEl, moveEv);

        await new Promise(r => setTimeout(r, STEP_MS));

      }

      const upEv = createPointerEvent('pointerup',

        Math.round(startX + totalDx),

        Math.round(startY + totalDy)

      );

      dispatchOn(mapEl, upEv);

      dispatchOn(document.elementFromPoint(

        Math.round(startX + totalDx),

        Math.round(startY + totalDy)

      ) || mapEl, upEv);

    } catch (e) {

    } finally {

      panningInProgress = false;

    }

  }

  async function loop() {

    if (!modeActive) return;



    roverEl = roverEl || findRover();

    mapEl = mapEl || findMap();



    if (!roverEl || !mapEl) {

      loopRaf = requestAnimationFrame(loop);

      return;

    }

    try {

      const rect = roverEl.getBoundingClientRect();

      const rx = rect.left + rect.width / 2;

      const ry = rect.top + rect.height / 2;

      const centerX = window.innerWidth / 2;

      const centerY = window.innerHeight / 2;

      const dx = centerX - rx;

      const dy = centerY - ry;

      const dist = Math.hypot(dx, dy);

      if (dist > DEAD_ZONE_RADIUS) {

        const applyDx = dx * SMOOTHNESS;

        const applyDy = dy * SMOOTHNESS;

        const cappedDx = Math.abs(applyDx) > MAX_GESTURE_PIXELS ?

          Math.sign(applyDx) * MAX_GESTURE_PIXELS : applyDx;

        const cappedDy = Math.abs(applyDy) > MAX_GESTURE_PIXELS ?

          Math.sign(applyDy) * MAX_GESTURE_PIXELS : applyDy;

        await syntheticPan(cappedDx, cappedDy);

      }

    } catch (e) {

    }

    if (modeActive) {

      setTimeout(() => {

        loopRaf = requestAnimationFrame(loop);

      }, STEP_MS);

    }

  }

  function startFollow() {

    if (modeActive) return;



    roverEl = findRover();

    mapEl = findMap();



    modeActive = true;

    btn.textContent = '🎯 Follow: On';

    btn.style.background = '#8A2BE2';



    setTimeout(() => {

      if (modeActive) loopRaf = requestAnimationFrame(loop);

    }, AUTO_CENTER_DELAY);

  }

  function stopFollow() {

    modeActive = false;

    btn.textContent = '🎯 Follow: Off';

    btn.style.background = '#8A2BE2';



    if (loopRaf) {

      cancelAnimationFrame(loopRaf);

      loopRaf = null;

    }

  }

  function init() {

    if (btn) return;



    btn = createButton();

    document.body.appendChild(btn);



    btn.onclick = () => {

      if (!modeActive) startFollow();

      else stopFollow();

    };

    let resizeTimeout;

    window.addEventListener('resize', () => {

      clearTimeout(resizeTimeout);

      resizeTimeout = setTimeout(() => {

        if (modeActive) {

          stopFollow();

          startFollow();

        }

      }, 250);

    });

  }

  if (document.readyState === 'loading') {

    document.addEventListener('DOMContentLoaded', init);

  } else {

    init();

  }

})();

