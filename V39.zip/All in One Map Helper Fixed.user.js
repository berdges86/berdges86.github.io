// ==UserScript==
// @name         All in One Map Helper Fixed
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  Показывает название трека, скрывает неактивные маршруты, делает маршруты оранжевыми
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Общие переменные для всех функций
    let trackNameLabel = null;
    let currentTrackName = '';
    let recordingState = 'idle';
    let isHidingRoutes = false;
    let isColorReplacementActive = false;

    // ==================== 📝 ФУНКЦИИ ДЛЯ НАЗВАНИЯ ТРЕКА ====================

    function createTrackNameLabel() {
        if (trackNameLabel) return;

        trackNameLabel = document.createElement('div');
        trackNameLabel.style.cssText = `
            position: fixed;
            top: 120px;
            left: 50%;
            transform: translateX(-50%);
            color: #ff69b4;
            opacity: 0.9;
            font-size: 18px;
            font-weight: bold;
            z-index: 100001;
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 15px;
            border-radius: 5px;
            display: none;
            transition: all 0.3s ease;
            pointer-events: none;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
            max-width: 90%;
            word-break: break-word;
        `;
        document.body.appendChild(trackNameLabel);
    }

    function getTrackName() {
        const selectors = [
            '.map-writing-panel-list-item_selected .map-writing-panel-track-info__header__info__title',
            '.map-writing-panel-list-item_selected .map-writing-panel-track-info__title',
            '.map-writing-panel-list-item_selected .track-info__title',
            '.map-writing-panel-list-item_selected .title',
            '.map-writing-panel-list-item_selected [class*="title"]',
            '.map-writing-panel-list-item_selected'
        ];

        for (let selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                const text = element.textContent?.trim();
                if (text && text.length > 0) {
                    return text;
                }
            }
        }
        return '';
    }

    function showNormalTrackName() {
        if (!trackNameLabel) return;

        currentTrackName = getTrackName();

        if (currentTrackName) {
            trackNameLabel.textContent = currentTrackName;
            trackNameLabel.style.display = 'block';
            trackNameLabel.style.opacity = '0.9';
            trackNameLabel.style.background = 'rgba(255, 255, 255, 0.15)';
            trackNameLabel.style.color = '#ff69b4';
        }
    }

    function showEnhancedTrackName() {
        if (!trackNameLabel) return;

        currentTrackName = getTrackName();

        if (currentTrackName) {
            trackNameLabel.textContent = currentTrackName;
            trackNameLabel.style.display = 'block';
            trackNameLabel.style.opacity = '1';
            trackNameLabel.style.background = 'rgba(255, 105, 180, 0.25)';
            trackNameLabel.style.color = '#ff1493';
            trackNameLabel.style.fontSize = '20px';
            trackNameLabel.style.boxShadow = '0 4px 12px rgba(255, 105, 180, 0.3)';
        }
    }

    function hideTrackName() {
        if (trackNameLabel) {
            trackNameLabel.style.display = 'none';
        }
    }

    // ==================== 🎯 ФУНКЦИИ ДЛЯ СКРЫТИЯ МАРШРУТОВ ====================

    function hideInactiveRoutes() {
        if (!isHidingRoutes) return;

        let hiddenCount = 0;

        document.querySelectorAll('path').forEach(p => {
            const stroke = p.getAttribute('stroke');
            const strokeOpacity = p.getAttribute('stroke-opacity');
            const strokeWidth = p.getAttribute('stroke-width');

            // Скрываем ТОЛЬКО полупрозрачные маршруты
            if (stroke === "#0077ff" &&
                strokeOpacity === "0.2" &&
                strokeWidth === "4.000") {

                if (p.style.display !== 'none') {
                    p.style.display = 'none';
                    p.setAttribute('data-hidden-route', 'true');
                    hiddenCount++;
                }
            }
        });

        if (isHidingRoutes) {
            setTimeout(hideInactiveRoutes, 500);
        }
    }

    function showAllRoutes() {
        let restoredCount = 0;

        document.querySelectorAll('path[data-hidden-route="true"]').forEach(p => {
            p.style.display = '';
            p.removeAttribute('data-hidden-route');
            restoredCount++;
        });
    }

    // ==================== 🟠 ФУНКЦИИ ДЛЯ ОРАНЖЕВЫХ МАРШРУТОВ ====================

    function replaceRouteColor() {
        if (!isColorReplacementActive) return;

        document.querySelectorAll('path').forEach(p => {
            // Ищем только основные маршруты (непрозрачные)
            if (p.getAttribute('stroke') === '#0077ff' &&
                p.getAttribute('stroke-width') === '4.000' &&
                (p.getAttribute('stroke-opacity') === '1' || !p.hasAttribute('stroke-opacity'))) {

                if (!p.hasAttribute('data-original-stroke')) {
                    p.setAttribute('data-original-stroke', p.getAttribute('stroke') || '');
                    p.setAttribute('data-original-stroke-width', p.getAttribute('stroke-width') || '');
                }

                p.setAttribute('stroke', '#FFA500');
                p.setAttribute('stroke-width', '6');
            }
        });

        if (isColorReplacementActive) {
            setTimeout(replaceRouteColor, 500);
        }
    }

    function restoreOriginalColors() {
        document.querySelectorAll('path').forEach(p => {
            if (p.hasAttribute('data-original-stroke')) {
                const originalStroke = p.getAttribute('data-original-stroke');
                const originalWidth = p.getAttribute('data-original-stroke-width');

                if (originalStroke) p.setAttribute('stroke', originalStroke);
                if (originalWidth) p.setAttribute('stroke-width', originalWidth);

                p.removeAttribute('data-original-stroke');
                p.removeAttribute('data-original-stroke-width');
            }
        });
    }

    // ==================== 🎮 ОБЩИЕ ФУНКЦИИ УПРАВЛЕНИЯ ====================

    function resetAllFeatures() {
        // Полный сброс всех состояний
        recordingState = 'idle';
        isHidingRoutes = false;
        isColorReplacementActive = false;

        hideTrackName();
        showAllRoutes();
        restoreOriginalColors();
    }

    function updateAllFeatures() {
        // Управление названием трека
        if (recordingState === 'started') {
            showNormalTrackName();
        } else if (recordingState === 'recording') {
            showEnhancedTrackName();
        } else {
            hideTrackName();
        }

        // Управление скрытием маршрутов - ТОЛЬКО во время записи
        if (recordingState === 'recording' && !isHidingRoutes) {
            isHidingRoutes = true;
            setTimeout(() => {
                hideInactiveRoutes();
            }, 100);
        } else if (recordingState !== 'recording' && isHidingRoutes) {
            isHidingRoutes = false;
            showAllRoutes();
        }

        // Управление оранжевыми маршрутами - ТОЛЬКО при выборе
        if (recordingState === 'started' && !isColorReplacementActive) {
            isColorReplacementActive = true;
            setTimeout(() => {
                replaceRouteColor();
            }, 100);
        } else if (recordingState !== 'started' && isColorReplacementActive) {
            isColorReplacementActive = false;
            restoreOriginalColors();
        }
    }

    // ==================== 🔍 ФУНКЦИИ ОТСЛЕЖИВАНИЯ ИНТЕРФЕЙСА ====================

    function setupFullPanelStartButton() {
        const selectedItem = document.querySelector('.map-writing-panel-list-item_selected');
        if (!selectedItem) return false;

        const buttonSelectors = [
            '.sdc-button__children',
            '.button__children',
            '[class*="button"]',
            'button'
        ];

        for (let selector of buttonSelectors) {
            const startButton = selectedItem.querySelector(selector);
            if (startButton && startButton.textContent?.trim() === 'Start') {
                const button = startButton.closest('button') || startButton;
                if (button && !button.hasAttribute('data-all-in-one-handler')) {
                    button.setAttribute('data-all-in-one-handler', 'true');
                    button.addEventListener('click', function() {
                        recordingState = 'recording';
                        updateAllFeatures();
                    });
                    return true;
                }
            }
        }
        return false;
    }

    function setupMiniPanelButtons() {
        const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');
        if (!miniPanel) return false;

        // Обработка кнопки записи
        const recordButton = miniPanel.querySelector('.map-writing-panel-mini__buttons__record');
        if (recordButton) {
            const captionSelectors = [
                '.map-writing-panel-mini__buttons__record__caption',
                '.record__caption',
                '[class*="caption"]',
                'span',
                'div'
            ];

            let buttonText = '';
            for (let selector of captionSelectors) {
                const caption = recordButton.querySelector(selector);
                if (caption) {
                    buttonText = caption.textContent?.trim();
                    if (buttonText) break;
                }
            }

            if (!buttonText) {
                buttonText = recordButton.textContent?.trim() || '';
            }

            if (buttonText.includes('Start record') && !recordButton.hasAttribute('data-start-record-handler')) {
                recordButton.setAttribute('data-start-record-handler', 'true');
                recordButton.addEventListener('click', function() {
                    recordingState = 'recording';
                    updateAllFeatures();
                });
            }

            if (buttonText.includes('Stop record') && !recordButton.hasAttribute('data-stop-record-handler')) {
                recordButton.setAttribute('data-stop-record-handler', 'true');
                recordButton.addEventListener('click', function() {
                    recordingState = 'stopped';
                    updateAllFeatures();
                });
            }
        }

        // Обработка кнопки ОТМЕНА (крестик) - ВАЖНО!
        const closeButton = miniPanel.querySelector('.map-writing-panel-mini__buttons__close');
        if (closeButton && !closeButton.hasAttribute('data-close-handler')) {
            closeButton.setAttribute('data-close-handler', 'true');
            closeButton.addEventListener('click', function() {
                // Полный сброс при нажатии отмены
                resetAllFeatures();
            });
        }

        // Обработка кнопки паузы
        const pauseButton = miniPanel.querySelector('.map-writing-panel-mini__buttons__pause');
        if (pauseButton && !pauseButton.hasAttribute('data-pause-handler')) {
            pauseButton.setAttribute('data-pause-handler', 'true');
            pauseButton.addEventListener('click', function() {
                if (recordingState === 'recording') {
                    recordingState = 'paused';
                    updateAllFeatures();
                }
            });
        }

        return true;
    }

    function handleSelectionChange() {
        const selectedItem = document.querySelector('.map-writing-panel-list-item_selected');
        if (selectedItem) {
            if (recordingState === 'idle' || recordingState === 'stopped') {
                recordingState = 'started';
                updateAllFeatures();
            }
        } else {
            // Если ничего не выбрано - сбрасываем в idle
            if (recordingState === 'started') {
                recordingState = 'idle';
                updateAllFeatures();
            }
        }
    }

    function startObservation() {
        const observer = new MutationObserver(function(mutations) {
            let shouldCheck = false;

            for (let mutation of mutations) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    shouldCheck = true;
                    break;
                }
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (mutation.target.classList.contains('map-writing-panel-list-item') ||
                        mutation.target.classList.contains('map-writing-screen__content__panel_mini') ||
                        mutation.target.classList.contains('map-writing-screen__content__panel_full')) {
                        shouldCheck = true;
                    }
                }
            }

            if (shouldCheck) {
                setTimeout(() => {
                    handleSelectionChange();
                    setupFullPanelStartButton();
                    setupMiniPanelButtons();

                    // Проверяем, если мини-панель исчезла - сбрасываем состояние
                    const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');
                    if (!miniPanel && recordingState !== 'idle') {
                        resetAllFeatures();
                    }
                }, 100);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class']
        });

        return observer;
    }

    function startBackupCheck() {
        setInterval(() => {
            setupFullPanelStartButton();
            setupMiniPanelButtons();
            handleSelectionChange();

            // Дополнительная проверка: если нет выбранного элемента и не в состоянии idle - сбрасываем
            const selectedItem = document.querySelector('.map-writing-panel-list-item_selected');
            const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');

            if (!selectedItem && !miniPanel && recordingState !== 'idle') {
                resetAllFeatures();
            }
        }, 1000);
    }

    function init() {
        createTrackNameLabel();
        startObservation();
        startBackupCheck();

        setTimeout(() => {
            setupFullPanelStartButton();
            setupMiniPanelButtons();
            handleSelectionChange();
        }, 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

