// ==UserScript==
// @name         Follow
// @namespace    Violentmonkey
// @version      6.1
// @description  Плавное следование за ровером
// @match        *://*/*
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    const ROVER_SELECTORS = [
        '.map-rover__icon',
        '.vector-map-rover__icon_icon_arrow',
        '[class*="rover__icon"]',
        '.vector-map-rover__icon.vector-map-rover__icon_icon_arrow.vector-map-rover__icon_animated'
    ];

    const MAP_SELECTORS = [
        '.sdc-vector-map-wrapper',
        '.sdc-map-wrapper',
        '.ymaps3x0--map-container',
        '.leaflet-container'
    ];

    const SMOOTHNESS = 0.25;
    const DEAD_ZONE_RADIUS = 40;
    const MAX_GESTURE_PIXELS = 120;
    const STEP_MS = 40;
    const AUTO_CENTER_DELAY = 220;

    let modeActive = false;
    let roverEl = null;
    let mapEl = null;
    let panningInProgress = false;
    let loopRaf = null;
    let btn = null;

    function findRover() {
        for (const selector of ROVER_SELECTORS) {
            const element = document.querySelector(selector);
            if (element) return element;
        }
        return null;
    }

    function findMap() {
        for (const selector of MAP_SELECTORS) {
            const element = document.querySelector(selector);
            if (element) return element;
        }
        return document.querySelector('.map') || document.querySelector('[role="application"]');
    }

    function createButton() {
        const button = document.createElement('button');
        button.textContent = '🎯 Follow: Off';
        Object.assign(button.style, {
            position: 'fixed',
            top: '200px',
            right: '20px',
            zIndex: 1000000,
            background: '#8A2BE2',
            color: '#fff',
            padding: '20px 30px',
            border: 'none',
            borderRadius: '12px',
            fontSize: '28px',
            fontWeight: 'bold',
            cursor: 'pointer',
            opacity: '0.9',
            minWidth: '200px',
            minHeight: '60px'
        });
        return button;
    }

    function createPointerEvent(type, clientX, clientY, pointerType = 'touch') {
        try {
            return new PointerEvent(type, {
                bubbles: true,
                cancelable: true,
                clientX,
                clientY,
                pointerType,
                isPrimary: true,
                pointerId: 1
            });
        } catch (error) {
            return new MouseEvent(type.replace('pointer', 'mouse'), {
                bubbles: true,
                cancelable: true,
                clientX,
                clientY,
                buttons: (type === 'pointerdown' || type === 'pointermove') ? 1 : 0
            });
        }
    }

    function dispatchOn(element, event) {
        try {
            return element.dispatchEvent(event);
        } catch (error) {
            return false;
        }
    }

    async function syntheticPan(deltaX, deltaY) {
        if (!mapEl || panningInProgress) return;

        panningInProgress = true;
        const startX = Math.floor(window.innerWidth / 2 - deltaX);
        const startY = Math.floor(window.innerHeight / 2 - deltaY);
        const totalDeltaX = deltaX;
        const totalDeltaY = deltaY;
        const stepsCount = Math.max(1, Math.ceil(Math.hypot(totalDeltaX, totalDeltaY) / Math.max(20, MAX_GESTURE_PIXELS / 2)));
        const stepDeltaX = totalDeltaX / stepsCount;
        const stepDeltaY = totalDeltaY / stepsCount;

        try {
            const downEvent = createPointerEvent('pointerdown', startX, startY);
            dispatchOn(mapEl, downEvent);
            dispatchOn(document.elementFromPoint(startX, startY) || mapEl, downEvent);

            for (let i = 1; i <= stepsCount; i++) {
                const pointX = Math.round(startX + stepDeltaX * i);
                const pointY = Math.round(startY + stepDeltaY * i);
                const moveEvent = createPointerEvent('pointermove', pointX, pointY);
                dispatchOn(mapEl, moveEvent);
                dispatchOn(document.elementFromPoint(pointX, pointY) || mapEl, moveEvent);
                await new Promise(resolve => setTimeout(resolve, STEP_MS));
            }

            const upEvent = createPointerEvent('pointerup',
                Math.round(startX + totalDeltaX),
                Math.round(startY + totalDeltaY)
            );
            dispatchOn(mapEl, upEvent);
            dispatchOn(document.elementFromPoint(
                Math.round(startX + totalDeltaX),
                Math.round(startY + totalDeltaY)
            ) || mapEl, upEvent);
        } catch (error) {
            // Ignore errors
        } finally {
            panningInProgress = false;
        }
    }

    async function loop() {
        if (!modeActive) return;

        roverEl = roverEl || findRover();
        mapEl = mapEl || findMap();

        if (!roverEl || !mapEl) {
            loopRaf = requestAnimationFrame(loop);
            return;
        }

        try {
            const rect = roverEl.getBoundingClientRect();
            const roverX = rect.left + rect.width / 2;
            const roverY = rect.top + rect.height / 2;
            const centerX = window.innerWidth / 2;
            const centerY = window.innerHeight / 2;
            const deltaX = centerX - roverX;
            const deltaY = centerY - roverY;
            const distance = Math.hypot(deltaX, deltaY);

            if (distance > DEAD_ZONE_RADIUS) {
                const applyDeltaX = deltaX * SMOOTHNESS;
                const applyDeltaY = deltaY * SMOOTHNESS;
                const cappedDeltaX = Math.abs(applyDeltaX) > MAX_GESTURE_PIXELS ?
                    Math.sign(applyDeltaX) * MAX_GESTURE_PIXELS : applyDeltaX;
                const cappedDeltaY = Math.abs(applyDeltaY) > MAX_GESTURE_PIXELS ?
                    Math.sign(applyDeltaY) * MAX_GESTURE_PIXELS : applyDeltaY;

                await syntheticPan(cappedDeltaX, cappedDeltaY);
            }
        } catch (error) {
            // Ignore errors
        }

        if (modeActive) {
            setTimeout(() => {
                loopRaf = requestAnimationFrame(loop);
            }, STEP_MS);
        }
    }

    function startFollow() {
        if (modeActive) return;

        roverEl = findRover();
        mapEl = findMap();
        modeActive = true;
        btn.textContent = '🎯 Follow: On';
        btn.style.background = '#32CD32';

        setTimeout(() => {
            if (modeActive) loopRaf = requestAnimationFrame(loop);
        }, AUTO_CENTER_DELAY);
    }

    function stopFollow() {
        modeActive = false;
        btn.textContent = '🎯 Follow: Off';
        btn.style.background = '#8A2BE2';

        if (loopRaf) {
            cancelAnimationFrame(loopRaf);
            loopRaf = null;
        }
    }

    function init() {
        if (btn) return;

        btn = createButton();
        document.body.appendChild(btn);

        btn.onclick = () => {
            if (!modeActive) startFollow();
            else stopFollow();
        };

        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                if (modeActive) {
                    stopFollow();
                    startFollow();
                }
            }, 250);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

