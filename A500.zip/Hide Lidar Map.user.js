// ==UserScript==
// @name        Hide Lidar Map
// @namespace   Violentmonkey Scripts
// @match       *://*/*
// @grant       none
// @version     1.0
// @author      -
// @description Скрывает лидарную
// ==/UserScript==

(function() {
    'use strict';

    const targetAttributes = {
        stroke: "#198cff",
        'stroke-opacity': "1",
        'stroke-width': "1.000"
    };

    const checkInterval = 150;
    let isActive = false;
    let hideButton = null;

    function createHideButton() {
        const button = document.createElement('button');
        button.textContent = 'Скрыть лидарную карту';
        button.style.position = 'fixed';
        button.style.top = '450px';
        button.style.left = '10px';
        button.style.zIndex = '10000';
        button.style.padding = '8px 12px';
        button.style.backgroundColor = '#198cff';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '5px';
        button.style.cursor = 'pointer';
        button.style.fontWeight = 'bold';
        button.style.fontSize = '12px';
        button.style.boxShadow = '0 2px 5px rgba(0,0,0,0.3)';

        button.addEventListener('click', () => {
            isActive = !isActive;
            button.textContent = isActive ? 'Выкл' : 'Скрыть лидарную карту';
            button.style.backgroundColor = isActive ? '#696969' : '#198cff';

            if (isActive) {
                startHidingElements();
            } else {
                showHiddenElements();
            }
        });

        document.body.appendChild(button);
        return button;
    }

    function hideElements() {
        if (!isActive) return;

        document.querySelectorAll('path').forEach(p => {
            const stroke = p.getAttribute('stroke');
            const strokeOpacity = p.getAttribute('stroke-opacity');
            const strokeWidth = p.getAttribute('stroke-width');

            if (stroke === targetAttributes.stroke &&
                strokeOpacity === targetAttributes['stroke-opacity'] &&
                strokeWidth === targetAttributes['stroke-width']) {

                p.style.display = 'none';
                p.setAttribute('data-original-display', 'none');
            }
        });

        if (isActive) {
            setTimeout(hideElements, checkInterval);
        }
    }

    function showHiddenElements() {
        document.querySelectorAll('path').forEach(p => {
            if (p.getAttribute('data-original-display') === 'none') {
                p.style.display = '';
                p.removeAttribute('data-original-display');
            }
        });
    }

    function startObserver() {
        const observer = new MutationObserver((mutations) => {
            if (!isActive) return;

            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1 && node.querySelectorAll) {
                        node.querySelectorAll('path').forEach(p => {
                            const stroke = p.getAttribute('stroke');
                            const strokeOpacity = p.getAttribute('stroke-opacity');
                            const strokeWidth = p.getAttribute('stroke-width');

                            if (stroke === targetAttributes.stroke &&
                                strokeOpacity === targetAttributes['stroke-opacity'] &&
                                strokeWidth === targetAttributes['stroke-width']) {

                                p.style.display = 'none';
                                p.setAttribute('data-original-display', 'none');
                            }
                        });
                    }
                });
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
        return observer;
    }

    function startHidingElements() {
        hideElements();
    }

    function init() {
        hideButton = createHideButton();
        startObserver();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

