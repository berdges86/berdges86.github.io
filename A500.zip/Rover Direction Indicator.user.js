// ==UserScript==
// @name         Rover Direction Indicator
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Показывает правильность направления движения ровера
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const passedPathSelector = 'path[stroke="#00cc44"][stroke-width="6.000"]';
    const futurePathSelector = 'path[stroke="#fa7559"][stroke-width="4.000"]';
    const roverSelector = '.vector-map-rover__icon_icon_arrow';

    let correctMessage, incorrectMessage;
    let correctTimeout, incorrectTimer;

    function createMessages() {
        correctMessage = document.createElement('div');
        correctMessage.textContent = 'Правильное направление';
        correctMessage.style.cssText = `
            position: fixed;
            top: 60px;
            left: 50%;
            transform: translateX(-50%);
            background: green;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 100000;
            display: none;
            font-size: 18px;
            font-weight: bold;
        `;

        incorrectMessage = document.createElement('div');
        incorrectMessage.textContent = 'Неправильное направление';
        incorrectMessage.style.cssText = `
            position: fixed;
            top: 60px;
            left: 50%;
            transform: translateX(-50%);
            background: red;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 100000;
            display: none;
            font-size: 18px;
            font-weight: bold;
        `;

        document.body.appendChild(correctMessage);
        document.body.appendChild(incorrectMessage);
    }

    function getRoverAngle(roverElement) {
        const inner = roverElement.querySelector('div');
        if (!inner) return 0;
        const style = inner.getAttribute('style');
        const match = style.match(/rotate\(([-+]?\d+(?:\.\d+)?)deg\)/);
        if (match) {
            return parseInt(match[1]) * Math.PI / 180;
        }
        return 0;
    }

    function getCenter(el) {
        const rect = el.getBoundingClientRect();
        return {
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
        };
    }

    function getNearestPaths(roverCenter, paths, maxDistance = 500) {
        const nearest = [];

        for (let path of paths) {
            const center = getCenter(path);
            const distance = Math.hypot(center.x - roverCenter.x, center.y - roverCenter.y);

            if (distance <= maxDistance) {
                nearest.push({
                    element: path,
                    center: center,
                    distance: distance
                });
            }
        }

        return nearest.sort((a, b) => a.distance - b.distance).slice(0, 5);
    }

    function getCenterOfMass(nearestPaths) {
        if (nearestPaths.length === 0) return null;

        let totalX = 0, totalY = 0;
        for (let item of nearestPaths) {
            totalX += item.center.x;
            totalY += item.center.y;
        }

        return {
            x: totalX / nearestPaths.length,
            y: totalY / nearestPaths.length
        };
    }

    function dot(v1, v2) {
        return v1.x * v2.x + v1.y * v2.y;
    }

    function magnitude(v) {
        return Math.sqrt(v.x * v.x + v.y * v.y);
    }

    function checkDirection() {
        const passedPaths = document.querySelectorAll(passedPathSelector);
        const futurePaths = document.querySelectorAll(futurePathSelector);
        const roverEl = document.querySelector(roverSelector);

        if (!roverEl || passedPaths.length === 0 || futurePaths.length === 0) {
            correctMessage.style.display = 'none';
            incorrectMessage.style.display = 'none';
            if (incorrectTimer) {
                clearTimeout(incorrectTimer);
                incorrectTimer = null;
            }
            return;
        }

        const roverCenter = getCenter(roverEl);

        const nearestPassed = getNearestPaths(roverCenter, passedPaths);
        const nearestFuture = getNearestPaths(roverCenter, futurePaths);

        if (nearestPassed.length === 0 || nearestFuture.length === 0) {
            correctMessage.style.display = 'none';
            incorrectMessage.style.display = 'none';
            return;
        }

        const passedCenter = getCenterOfMass(nearestPassed);
        const futureCenter = getCenterOfMass(nearestFuture);

        if (!passedCenter || !futureCenter) return;

        const toFuture = {
            x: futureCenter.x - roverCenter.x,
            y: futureCenter.y - roverCenter.y
        };

        const roverAngle = getRoverAngle(roverEl);
        const roverDirection = {
            x: Math.cos(roverAngle),
            y: Math.sin(roverAngle)
        };

        const lengthToFuture = magnitude(toFuture);
        if (lengthToFuture === 0) return;

        const normalizedToFuture = {
            x: toFuture.x / lengthToFuture,
            y: toFuture.y / lengthToFuture
        };

        const dotProduct = dot(roverDirection, normalizedToFuture);

        const isCorrect = dotProduct > 0;

        if (isCorrect) {
            correctMessage.style.display = 'block';
            clearTimeout(correctTimeout);
            correctTimeout = setTimeout(() => {
                correctMessage.style.display = 'none';
            }, 5000);

            if (incorrectTimer) {
                clearTimeout(incorrectTimer);
                incorrectTimer = null;
            }
            incorrectMessage.style.display = 'none';
        } else {
            if (!incorrectTimer) {
                incorrectTimer = setTimeout(() => {
                    incorrectMessage.style.display = 'block';
                }, 10000);
            }
        }
    }

    function init() {
        createMessages();
        setInterval(checkDirection, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

