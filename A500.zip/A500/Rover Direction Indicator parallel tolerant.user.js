// ==UserScript==
// @name         Rover Direction Indicator Fixed
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Показывает правильность направления движения ровера (исправленная версия)
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const passedPathSelector = 'path[stroke="#00cc44"][stroke-width="6.000"]';
    const futurePathSelector = 'path[stroke="#fa7559"][stroke-width="4.000"]';
    const roverSelector = '.vector-map-rover__icon_icon_arrow';

    let correctMessage, incorrectMessage;
    let correctTimeout, incorrectTimer;

    function createMessages() {
        correctMessage = document.createElement('div');
        correctMessage.textContent = 'Правильное направление';
        correctMessage.style.cssText = `
            position: fixed;
            top: 50px;
            left: 50%;
            transform: translateX(-50%);
            background: green;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 100000;
            display: none;
            font-size: 18px;
            font-weight: bold;
        `;

        incorrectMessage = document.createElement('div');
        incorrectMessage.textContent = 'Неправильное направление';
        incorrectMessage.style.cssText = `
            position: fixed;
            top: 50px;
            left: 50%;
            transform: translateX(-50%);
            background: red;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 100000;
            display: none;
            font-size: 18px;
            font-weight: bold;
        `;

        document.body.appendChild(correctMessage);
        document.body.appendChild(incorrectMessage);
    }

    function getRoverAngle(roverElement) {
        const inner = roverElement.querySelector('div');
        if (!inner) return 0;
        const style = inner.getAttribute('style');
        const match = style.match(/rotate\(([-+]?\d+(?:\.\d+)?)deg\)/);
        if (match) {
            // Преобразуем в радианы и корректируем систему координат
            let degrees = parseFloat(match[1]);
            
            // Корректировка системы координат:
            // 0° = север (12 часов) = -90° в математической системе
            // Поворачиваем на -90°, чтобы 0° стал севером
            degrees = degrees - 90;
            
            return degrees * Math.PI / 180;
        }
        return -Math.PI / 2; // По умолчанию север (90° в математической системе)
    }

    function getCenter(el) {
        const rect = el.getBoundingClientRect();
        return {
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
        };
    }

    function getCenterOfMass(elements) {
        if (elements.length === 0) return null;
        let totalX = 0, totalY = 0;
        for (let el of elements) {
            const center = getCenter(el);
            totalX += center.x;
            totalY += center.y;
        }
        return {
            x: totalX / elements.length,
            y: totalY / elements.length
        };
    }

    function dot(v1, v2) {
        return v1.x * v2.x + v1.y * v2.y;
    }

    function magnitude(v) {
        return Math.sqrt(v.x * v.x + v.y * v.y);
    }

    function checkDirection() {
        const passedPaths = document.querySelectorAll(passedPathSelector);
        const futurePaths = document.querySelectorAll(futurePathSelector);
        const roverEl = document.querySelector(roverSelector);

        if (!roverEl || passedPaths.length === 0 || futurePaths.length === 0) {
            correctMessage.style.display = 'none';
            incorrectMessage.style.display = 'none';
            if (incorrectTimer) {
                clearTimeout(incorrectTimer);
                incorrectTimer = null;
            }
            return;
        }

        const roverCenter = getCenter(roverEl);
        const passedCenter = getCenterOfMass(passedPaths);
        const futureCenter = getCenterOfMass(futurePaths);

        if (!passedCenter || !futureCenter) return;

        const toFuture = {
            x: futureCenter.x - roverCenter.x,
            y: futureCenter.y - roverCenter.y
        };

        const roverAngle = getRoverAngle(roverEl);
        const roverDirection = {
            x: Math.cos(roverAngle),
            y: Math.sin(roverAngle)
        };

        const lengthToFuture = magnitude(toFuture);
        if (lengthToFuture === 0) return;
        const normalizedToFuture = {
            x: toFuture.x / lengthToFuture,
            y: toFuture.y / lengthToFuture
        };

        const dotProduct = dot(roverDirection, normalizedToFuture);

        // Увеличиваем допуск для лучшей стабильности
        const isCorrect = dotProduct > 0.3; // был > 0

        if (isCorrect) {
            correctMessage.style.display = 'block';
            clearTimeout(correctTimeout);
            correctTimeout = setTimeout(() => {
                correctMessage.style.display = 'none';
            }, 5000);

            if (incorrectTimer) {
                clearTimeout(incorrectTimer);
                incorrectTimer = null;
            }
            incorrectMessage.style.display = 'none';
        } else {
            if (!incorrectTimer) {
                incorrectTimer = setTimeout(() => {
                    incorrectMessage.style.display = 'block';
                }, 10000);
            }
        }
    }

    function init() {
        createMessages();
        setInterval(checkDirection, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();