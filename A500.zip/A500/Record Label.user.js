// ==UserScript==
// @name         Track Name Display
// @namespace    http://tampermonkey.net/
// @version      2.3
// @description  Показывает название трека при записи маршрута
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let trackNameLabel = null;
    let currentTrackName = '';
    let recordingState = 'idle';

    function createTrackNameLabel() {
        if (trackNameLabel) return;

        trackNameLabel = document.createElement('div');
        trackNameLabel.style.cssText = `
            position: fixed;
            top: 90px;
            left: 50%;
            transform: translateX(-50%);
            color: pink;
            opacity: 0.75;
            font-size: 20px;
            font-weight: bold;
            z-index: 100001;
            background: transparent;
            padding: 5px 10px;
            border-radius: 3px;
            display: none;
            transition: all 0.3s ease;
        `;
        document.body.appendChild(trackNameLabel);
    }

    function getTrackName() {
        const selectedItem = document.querySelector('.map-writing-panel-list-item_selected');
        if (selectedItem) {
            const titleElement = selectedItem.querySelector('.map-writing-panel-track-info__header__info__title');
            return titleElement ? titleElement.textContent.trim() : '';
        }
        return '';
    }

    function showNormalTrackName() {
        if (!trackNameLabel || !currentTrackName) return;
        
        trackNameLabel.textContent = currentTrackName;
        trackNameLabel.style.display = 'block';
        trackNameLabel.style.opacity = '0.75';
        trackNameLabel.style.background = 'transparent';
        trackNameLabel.style.color = 'pink';
        trackNameLabel.style.padding = '5px 10px';
        trackNameLabel.style.borderRadius = '3px';
        trackNameLabel.style.backdropFilter = 'none';
        trackNameLabel.style.border = 'none';
    }

    function showEnhancedTrackName() {
        if (!trackNameLabel || !currentTrackName) return;
        
        trackNameLabel.textContent = currentTrackName;
        trackNameLabel.style.display = 'block';
        trackNameLabel.style.opacity = '0.9';
        trackNameLabel.style.background = 'rgba(255, 255, 255, 0.15)';
        trackNameLabel.style.color = '#ff69b4';
        trackNameLabel.style.padding = '8px 15px';
        trackNameLabel.style.borderRadius = '5px';
        trackNameLabel.style.backdropFilter = 'blur(5px)';
        trackNameLabel.style.border = '1px solid rgba(255, 255, 255, 0.2)';
    }

    function hideTrackName() {
        if (trackNameLabel) {
            trackNameLabel.style.display = 'none';
        }
    }

    function setupFullPanelStartButton() {
        const startButton = document.querySelector('.sdc-button__children');
        if (startButton && startButton.textContent.trim() === 'Start') {
            const button = startButton.closest('button');
            if (button && !button.hasAttribute('data-track-handler')) {
                button.setAttribute('data-track-handler', 'true');
                button.addEventListener('click', function() {
                    currentTrackName = getTrackName();
                    recordingState = 'started';
                    showNormalTrackName();
                });
                return true;
            }
        }
        return false;
    }

    function setupMiniPanelButtons() {
        const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');
        if (!miniPanel) return false;

        const recordButton = miniPanel.querySelector('.map-writing-panel-mini__buttons__record');
        if (!recordButton) return false;

        const caption = recordButton.querySelector('.map-writing-panel-mini__buttons__record__caption');
        if (!caption) return false;

        const buttonText = caption.textContent.trim();

        if (buttonText === 'Start record' && !recordButton.hasAttribute('data-start-handler')) {
            recordButton.setAttribute('data-start-handler', 'true');
            recordButton.addEventListener('click', function() {
                if (recordingState === 'started') {
                    recordingState = 'recording';
                    showEnhancedTrackName();
                }
            });
            return true;
        }

        if (buttonText === 'Stop record' && !recordButton.hasAttribute('data-stop-handler')) {
            recordButton.setAttribute('data-stop-handler', 'true');
            recordButton.addEventListener('click', function() {
                recordingState = 'stopped';
                hideTrackName();
            });
            return true;
        }

        return false;
    }

    function startObservation() {
        const observer = new MutationObserver(function(mutations) {
            let shouldCheckFullPanel = false;
            let shouldCheckMiniPanel = false;

            for (let mutation of mutations) {
                if (mutation.type === 'childList') {
                    for (let node of mutation.addedNodes) {
                        if (node.nodeType === 1) {
                            if (node.classList && node.classList.contains('map-writing-screen__content__panel_full') ||
                                node.querySelector && node.querySelector('.map-writing-screen__content__panel_full')) {
                                shouldCheckFullPanel = true;
                            }
                            if (node.classList && node.classList.contains('map-writing-screen__content__panel_mini') ||
                                node.querySelector && node.querySelector('.map-writing-screen__content__panel_mini')) {
                                shouldCheckMiniPanel = true;
                            }
                        }
                    }
                }
            }

            if (shouldCheckFullPanel) {
                const fullPanel = document.querySelector('.map-writing-screen__content__panel_full');
                if (fullPanel && !fullPanel.hasAttribute('data-track-handler')) {
                    fullPanel.setAttribute('data-track-handler', 'true');
                    setTimeout(() => {
                        setupFullPanelStartButton();
                    }, 100);
                }
            }

            if (shouldCheckMiniPanel) {
                const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');
                if (miniPanel) {
                    setTimeout(() => {
                        setupMiniPanelButtons();
                    }, 100);
                }
            }

            setupMiniPanelButtons();
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'style']
        });

        return observer;
    }

    function startBackupCheck() {
        setInterval(() => {
            const fullPanel = document.querySelector('.map-writing-screen__content__panel_full');
            if (fullPanel && !fullPanel.hasAttribute('data-track-handler')) {
                fullPanel.setAttribute('data-track-handler', 'true');
                setupFullPanelStartButton();
            }

            setupMiniPanelButtons();

            const miniPanel = document.querySelector('.map-writing-screen__content__panel_mini');
            if (!miniPanel && recordingState !== 'idle') {
                recordingState = 'idle';
                hideTrackName();
            }
        }, 1000);
    }

    function init() {
        createTrackNameLabel();
        startObservation();
        startBackupCheck();

        setTimeout(() => {
            const fullPanel = document.querySelector('.map-writing-screen__content__panel_full');
            if (fullPanel) {
                fullPanel.setAttribute('data-track-handler', 'true');
                setupFullPanelStartButton();
            }
            setupMiniPanelButtons();
        }, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();