// ==UserScript==
// @name         Rover Direction Indicator Fixed - Improved A
// @namespace    http://tampermonkey.net/
// @version      0.3
// @description  Улучшенная проверка направления: ближайшие сегменты пути, устойчивость, корректный парсер угла.
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Настройки (подстраивайте при необходимости)
    const passedPathSelector = 'path[stroke="#00cc44"][stroke-width="6.000"]';
    const futurePathSelector = 'path[stroke="#fa7559"][stroke-width="4.000"]';
    const roverSelector = '.vector-map-rover__icon_icon_arrow';
    const SEARCH_RADIUS = 30; // пикселей: искать точки пути в этом радиусе
    const SAMPLE_STEP = 6; // px при выборке точек по длине path
    const TANGENT_DELTA = 8; // px для вычисления касательной (точка дальше по path)
    const CHECK_INTERVAL_MS = 250;
    const SHOW_AFTER_MS = 2000; // сколько должны держаться неправильность/правильность чтобы показать
    const HIDE_AFTER_MS = 2000;

    // UI
    let correctMessage, incorrectMessage;
    function createMessages() {
        correctMessage = document.createElement('div');
        correctMessage.textContent = 'Правильное направление';
        Object.assign(correctMessage.style, {
            position: 'fixed', top: '50px', left: '50%', transform: 'translateX(-50%)',
            background: 'green', color: 'white', padding: '10px 20px', borderRadius: '5px',
            zIndex: 100000, display: 'none', fontSize: '18px', fontWeight: 'bold'
        });

        incorrectMessage = document.createElement('div');
        incorrectMessage.textContent = 'Неправильное направление';
        Object.assign(incorrectMessage.style, {
            position: 'fixed', top: '50px', left: '50%', transform: 'translateX(-50%)',
            background: 'red', color: 'white', padding: '10px 20px', borderRadius: '5px',
            zIndex: 100000, display: 'none', fontSize: '18px', fontWeight: 'bold'
        });

        document.body.appendChild(correctMessage);
        document.body.appendChild(incorrectMessage);
    }

    // Вспомогательные
    function getCenter(el) {
        const r = el.getBoundingClientRect();
        return { x: r.left + r.width/2, y: r.top + r.height/2 };
    }
    function mag(v){ return Math.sqrt(v.x*v.x + v.y*v.y) || 1e-9; }
    function normalize(v){ const m = mag(v); return { x: v.x/m, y: v.y/m }; }
    function dot(a,b){ return a.x*b.x + a.y*b.y; }
    function dist(a,b){ const dx=a.x-b.x, dy=a.y-b.y; return Math.sqrt(dx*dx+dy*dy); }

    // Надёжный парсер угла/вектора стрелки ровера
    function getRoverAngleRad(roverElement) {
        if (!roverElement) return null;
        // ищем внутренний элемент, где обычно поворот применяется
        const inner = roverElement.querySelector('div') || roverElement;
        // 1) style transform: rotate(XXdeg)
        const style = inner.style && inner.style.transform;
        if (style) {
            const m = style.match(/rotate\(([-+0-9.]+)deg\)/);
            if (m) return (parseFloat(m[1]) - 90) * Math.PI/180; // выровнять: 0deg -> вверх
        }
        // 2) атрибут transform (SVG)
        const attr = inner.getAttribute && inner.getAttribute('transform');
        if (attr) {
            const m2 = attr.match(/rotate\(([-+0-9.]+)\)/);
            if (m2) return (parseFloat(m2[1]) - 90) * Math.PI/180;
        }
        // 3) computed matrix: matrix(a,b,c,d,tx,ty)
        const cs = window.getComputedStyle(inner);
        const matrix = cs.transform || cs.webkitTransform;
        if (matrix && matrix !== 'none') {
            const vals = matrix.match(/matrix\(([^\)]+)\)/);
            if (vals) {
                const parts = vals[1].split(',').map(s=>parseFloat(s));
                // matrix(a, b, c, d, tx, ty) => x-axis maps to (a,b)
                const a = parts[0], b = parts[1];
                const angle = Math.atan2(b, a); // угол относительно +X
                return angle - Math.PI/2; // сдвиг: 0->вверх
            }
        }
        return null;
    }

    // Найти ближайшую точку path к точке p (в экранных координатах),
    // возвращает {dist, point:{x,y}, tangent:{x,y}, path, length}
    function findNearestPointOnPath(pathEl, p) {
        try {
            const L = pathEl.getTotalLength();
            let best = {dist: Infinity, point: null, length: 0};
            for (let len = 0; len <= L; len += SAMPLE_STEP) {
                const pt = pathEl.getPointAtLength(len);
                const dx = pt.x - p.x, dy = pt.y - p.y;
                const d = Math.sqrt(dx*dx + dy*dy);
                if (d < best.dist) {
                    best = {dist: d, point: {x: pt.x, y: pt.y}, length: len};
                }
            }
            // уточнить вокруг лучшей length мелким шагом
            const start = Math.max(0, best.length - SAMPLE_STEP);
            const end = Math.min(L, best.length + SAMPLE_STEP);
            for (let len=start; len<=end; len += 1) {
                const pt = pathEl.getPointAtLength(len);
                const d = Math.hypot(pt.x - p.x, pt.y - p.y);
                if (d < best.dist) {
                    best = {dist: d, point: {x: pt.x, y: pt.y}, length: len};
                }
            }
            // получить касательную (точка чуть дальше)
            const len2 = Math.min(L, best.length + TANGENT_DELTA);
            const p2 = pathEl.getPointAtLength(len2);
            const tangent = { x: p2.x - best.point.x, y: p2.y - best.point.y };
            return {...best, tangent};
        } catch(e) {
            return null;
        }
    }

    // Основная проверка
    let state = { lastCheck: 0, wrongSince: null, rightSince: null };
    function checkDirection() {
        const roverEl = document.querySelector(roverSelector);
        const futurePaths = document.querySelectorAll(futurePathSelector);
        const passedPaths = document.querySelectorAll(passedPathSelector);

        if (!roverEl || futurePaths.length === 0) {
            // ничего не показываем
            correctMessage.style.display = 'none';
            incorrectMessage.style.display = 'none';
            state.wrongSince = state.rightSince = null;
            return;
        }

        const roverCenter = getCenter(roverEl);
        const roverAngle = getRoverAngleRad(roverEl);
        const headingVec = roverAngle !== null ? { x: Math.cos(roverAngle), y: Math.sin(roverAngle) } : null;

        // Найдем ближайшую точку на ближайшем "future" пути в радиусе SEARCH_RADIUS
        let bestOverall = { dist: Infinity, info: null };
        futurePaths.forEach(p => {
            const info = findNearestPointOnPath(p, roverCenter);
            if (info && info.dist < bestOverall.dist) bestOverall = { dist: info.dist, info: info, path: p };
        });

        let correct = false;
        if (bestOverall.info && bestOverall.dist <= SEARCH_RADIUS) {
            // есть близкая точка на будущей части маршрута
            const tangent = normalize(bestOverall.info.tangent);
            // tangent сейчас направлен в сторону увеличения длины path,
            // но это может быть либо в направление дальше по маршруту, либо наоборот.
            // Попробуем согласовать направление касательной так, чтобы она шла от пройденного (passed) к будущему.
            // Для этого возьмём центр пройденных путей (если есть) и проверим.
            let passedCenter = null;
            if (passedPaths.length > 0) {
                let sx=0, sy=0;
                passedPaths.forEach(pp => { const c = pp.getBoundingClientRect(); sx += c.left + c.width/2; sy += c.top + c.height/2; });
                passedCenter = { x: sx/passedPaths.length, y: sy/passedPaths.length };
            }
            if (passedCenter) {
                const fromPassedToTangent = normalize({ x: bestOverall.info.point.x - passedCenter.x, y: bestOverall.info.point.y - passedCenter.y });
                if (dot(fromPassedToTangent, tangent) < 0) {
                    // касательная направлена в противоположную сторону от пройденного -> инвертируем
                    tangent.x *= -1; tangent.y *= -1;
                }
            }
            // Теперь сравниваем headingVec и tangent
            if (headingVec) {
                const dp = dot(normalize(headingVec), normalize(tangent));
                // порог - можно подстраивать; >0.5 — довольно строго (около 60°)
                correct = dp > 0.35;
            } else {
                // если нет угла, будем считать по направлению от пройденного к будущему (fallback)
                correct = true;
            }
        } else {
            // Фоллбек — ближайшая логика по центрам масс (как раньше), но с более мягким порогом
            if (passedPaths.length > 0 && futurePaths.length > 0) {
                const pCenter = ( () => {
                    let sx=0, sy=0;
                    passedPaths.forEach(pp => { const c = pp.getBoundingClientRect(); sx += c.left + c.width/2; sy += c.top + c.height/2; });
                    return { x: sx/passedPaths.length, y: sy/passedPaths.length };
                })();
                const fCenter = ( () => {
                    let sx=0, sy=0;
                    futurePaths.forEach(pp => { const c = pp.getBoundingClientRect(); sx += c.left + c.width/2; sy += c.top + c.height/2; });
                    return { x: sx/futurePaths.length, y: sy/futurePaths.length };
                })();
                const toFuture = normalize({ x: fCenter.x - roverCenter.x, y: fCenter.y - roverCenter.y });
                if (headingVec) {
                    correct = dot(normalize(headingVec), toFuture) > 0.25;
                } else {
                    correct = dot(toFuture, {x:0,y:-1}) > 0; // fallback: смотрит вверх-ish?
                }
            } else {
                correct = true; // если мало данных, не считать ошибкой
            }
        }

        // Устойчивость: индикация появляется только если состояние держится SHOW_AFTER_MS
        const now = performance.now();
        if (correct) {
            state.wrongSince = null;
            if (state.rightSince == null) state.rightSince = now;
            if (now - state.rightSince >= SHOW_AFTER_MS) {
                correctMessage.style.display = 'block';
                incorrectMessage.style.display = 'none';
            }
        } else {
            state.rightSince = null;
            if (state.wrongSince == null) state.wrongSince = now;
            if (now - state.wrongSince >= SHOW_AFTER_MS) {
                incorrectMessage.style.display = 'block';
                correctMessage.style.display = 'none';
            }
        }
    }

    function init() {
        createMessages();
        setInterval(checkDirection, CHECK_INTERVAL_MS);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

})();

