// ==UserScript==
// @name         Rover Direction Indicator - Motion-aware B
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Логика на основе направления стрелки + вектора движения (анализ позиций во времени) + ближайший сегмент пути.
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const futurePathSelector = 'path[stroke="#fa7559"][stroke-width="4.000"]';
    const passedPathSelector = 'path[stroke="#00cc44"][stroke-width="6.000"]';
    const roverSelector = '.vector-map-rover__icon_icon_arrow';

    const SAMPLE_STEP = 6;
    const SEARCH_RADIUS = 30;
    const TANGENT_DELTA = 6;
    const CHECK_INTERVAL = 200;
    const SPEED_WINDOW_MS = 600; // окно для оценки движения
    const MIN_MOVE_PX = 1.5; // минимальное перемещение, чтобы считать, что ровер едет
    const SHOW_AFTER_MS = 1800;

    // UI
    let correctEl, incorrectEl;
    function makeUI() {
        correctEl = document.createElement('div'); incorrectEl = document.createElement('div');
        correctEl.textContent = 'Правильное направление'; incorrectEl.textContent = 'Неправильное направление';
        Object.assign(correctEl.style, {position:'fixed', top:'50px', left:'50%', transform:'translateX(-50%)', background:'green', color:'#fff', padding:'10px 18px', borderRadius:'6px', fontWeight:'700', display:'none', zIndex:100000});
        Object.assign(incorrectEl.style, {position:'fixed', top:'50px', left:'50%', transform:'translateX(-50%)', background:'red', color:'#fff', padding:'10px 18px', borderRadius:'6px', fontWeight:'700', display:'none', zIndex:100000});
        document.body.appendChild(correctEl); document.body.appendChild(incorrectEl);
    }

    // вспомогательные
    function getCenter(el) { const r = el.getBoundingClientRect(); return {x: r.left + r.width/2, y: r.top + r.height/2}; }
    function normalize(v){ const m=Math.hypot(v.x,v.y)||1; return {x:v.x/m, y:v.y/m}; }
    function dot(a,b){return a.x*b.x + a.y*b.y;}
    function getAngleRadFromEl(el) {
        const inner = el.querySelector('div') || el;
        const style = inner.style && inner.style.transform;
        if (style) {
            const m = style.match(/rotate\(([-+0-9.]+)deg\)/);
            if (m) return (parseFloat(m[1]) - 90) * Math.PI/180;
        }
        const attr = inner.getAttribute && inner.getAttribute('transform');
        if (attr) {
            const m2 = attr.match(/rotate\(([-+0-9.]+)\)/);
            if (m2) return (parseFloat(m2[1]) - 90) * Math.PI/180;
        }
        const cs = window.getComputedStyle(inner);
        const mat = cs.transform;
        if (mat && mat !== 'none') {
            const vals = mat.match(/matrix\(([^)]+)\)/);
            if (vals) {
                const parts = vals[1].split(',').map(s=>parseFloat(s));
                const a = parts[0], b = parts[1];
                return Math.atan2(b,a) - Math.PI/2;
            }
        }
        return null;
    }

    function findNearestOnPath(pathEl, p) {
        try {
            const L = pathEl.getTotalLength();
            let best = {d: Infinity, len: 0, pt: null};
            for (let l=0; l<=L; l+=SAMPLE_STEP) {
                const pt = pathEl.getPointAtLength(l);
                const d = Math.hypot(pt.x - p.x, pt.y - p.y);
                if (d < best.d) { best = {d, len: l, pt:{x:pt.x,y:pt.y}}; }
            }
            // уточнение
            const s = Math.max(0, best.len - SAMPLE_STEP), e = Math.min(L, best.len + SAMPLE_STEP);
            for (let l=s; l<=e; l+=1) {
                const pt = pathEl.getPointAtLength(l);
                const d = Math.hypot(pt.x - p.x, pt.y - p.y);
                if (d < best.d) { best = {d, len: l, pt:{x:pt.x,y:pt.y}}; }
            }
            const l2 = Math.min(L, best.len + TANGENT_DELTA);
            const p2 = pathEl.getPointAtLength(l2);
            return {dist: best.d, point: best.pt, tangent: {x: p2.x - best.pt.x, y: p2.y - best.pt.y}, len: best.len};
        } catch(e) { return null; }
    }

    // движение: сохраняем историю позиций
    const posHistory = [];
    function pushPos(p) {
        const now = Date.now();
        posHistory.push({t: now, p});
        // очищаем старые записи
        while (posHistory.length && now - posHistory[0].t > SPEED_WINDOW_MS*2) posHistory.shift();
    }
    function estimateVelocity() {
        if (posHistory.length < 2) return {vx:0, vy:0, speed:0};
        const now = Date.now();
        // возьмём самую старую и самую новую в окне SPEED_WINDOW_MS
        let startIdx = 0;
        for (let i=0;i<posHistory.length;i++) if (now - posHistory[i].t <= SPEED_WINDOW_MS) { startIdx = i; break; }
        const start = posHistory[startIdx];
        const end = posHistory[posHistory.length-1];
        const dt = (end.t - start.t) / 1000;
        if (dt <= 0) return {vx:0,vy:0,speed:0};
        const vx = (end.p.x - start.p.x) / dt;
        const vy = (end.p.y - start.p.y) / dt;
        return {vx, vy, speed: Math.hypot(vx, vy)};
    }

    let state = { sinceWrong: null, sinceRight: null };

    function checkOnce() {
        const roverEl = document.querySelector(roverSelector);
        const futurePaths = document.querySelectorAll(futurePathSelector);
        const passedPaths = document.querySelectorAll(passedPathSelector);

        if (!roverEl || futurePaths.length === 0) {
            correctEl.style.display = incorrectEl.style.display = 'none';
            state.sinceWrong = state.sinceRight = null;
            return;
        }

        const rc = getCenter(roverEl);
        pushPos(rc);
        const vel = estimateVelocity();
        const moving = vel.speed > MIN_MOVE_PX; // px/sec threshold * dt normalised

        // Найдём ближайшую точку на future-пути
        let best = {dist: Infinity, info: null, path: null};
        futurePaths.forEach(p => {
            const i = findNearestOnPath(p, rc);
            if (i && i.dist < best.dist) best = {dist: i.dist, info: i, path: p};
        });

        // определим эталонный вектор: если есть близкая точка -> касательная (направляем от пройденного к будущему)
        let referenceVec = null;
        if (best.info && best.dist <= SEARCH_RADIUS) {
            referenceVec = normalize(best.info.tangent);
            // согласуем направление касательной по отношению к green paths center
            if (passedPaths.length > 0) {
                let sx=0, sy=0;
                passedPaths.forEach(pp => { const c=pp.getBoundingClientRect(); sx += c.left + c.width/2; sy += c.top + c.height/2; });
                const pc = {x: sx/ passedPaths.length, y: sy/ passedPaths.length};
                const fromPassed = normalize({x: best.info.point.x - pc.x, y: best.info.point.y - pc.y});
                if (dot(fromPassed, referenceVec) < 0) { referenceVec.x *= -1; referenceVec.y *= -1; }
            }
        } else {
            // fallback: центр будущего пути
            if (futurePaths.length > 0) {
                let sx=0, sy=0;
                futurePaths.forEach(pp => { const c=pp.getBoundingClientRect(); sx += c.left + c.width/2; sy += c.top + c.height/2; });
                const fc = {x: sx/futurePaths.length, y: sy/futurePaths.length};
                referenceVec = normalize({x: fc.x - rc.x, y: fc.y - rc.y});
            }
        }

        // heading вектор от угла стрелки
        const ang = getAngleRadFromEl(roverEl);
        const headingVec = ang !== null ? normalize({x: Math.cos(ang), y: Math.sin(ang)}) : null;

        // motionVec — направление реального движения (если движется)
        const motionVec = (vel.speed > 0) ? normalize({x: vel.vx, y: vel.vy}) : null;

        // Правильность определим так:
        // - если есть motionVec (ровер реально едет): считаем его главным — должен соотв. referenceVec
        // - иначе сравниваем headingVec с referenceVec
        let correct = true;
        if (referenceVec) {
            if (motionVec && vel.speed > 5) { // если реально двигается заметно
                correct = dot(motionVec, referenceVec) > 0.4; // требуем более строгого совпадения
            } else if (headingVec) {
                correct = dot(headingVec, referenceVec) > 0.35;
            } else {
                // нет данных — считаем корректным
                correct = true;
            }
        }

        const now = performance.now();
        if (correct) {
            state.sinceWrong = null;
            if (state.sinceRight == null) state.sinceRight = now;
            if (now - state.sinceRight >= SHOW_AFTER_MS) {
                correctEl.style.display = 'block';
                incorrectEl.style.display = 'none';
            }
        } else {
            state.sinceRight = null;
            if (state.sinceWrong == null) state.sinceWrong = now;
            if (now - state.sinceWrong >= SHOW_AFTER_MS) {
                incorrectEl.style.display = 'block';
                correctEl.style.display = 'none';
            }
        }
    }

    function start() { makeUI(); setInterval(checkOnce, CHECK_INTERVAL); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();

})();

